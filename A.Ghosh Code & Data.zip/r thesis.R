library(readxl)
GroupA <- read_excel("GroupA.xlsx")
View(GroupA)
GroupB <- read_excel("GroupB.xlsx", sheet = "Non Violent")
View(GroupB)
#other necessary packages
library(ggplot2)
library(plyr)
library(tidyverse)
library(psych)
library(dplyr)
#quick verification and overview of groups
summary(GroupA)
summary(GroupB)
#cronbach alpha
combined <- rbind(GroupA,GroupB)
View(combined)
questionnaire.data <- combined[,2:26]
View(questionnaire.data)
result <- alpha(questionnaire.data)
cronbach_alpha <- result$alpha
#all raw_alphas are above 0.7 therefore
#indicating consistency.
#decriptive stats time
table(combined$Participants) #distributions
#50-50 in my case
summary(GroupA$`Average Score per part`)
summary(GroupB$`Average Score per part`)
sd(GroupA$`Average Score per part`)
sd(GroupB$`Average Score per part`)
#time for charts and to check for distribution
hist(GroupA$`Average Score per part`)
ggplot(corcombined, aes(x = GroupA, fill ="red"))+ geom_histogram(binwidth = 0.2) + xlab("Group A") + ylab("Scores")
hist(GroupB$`Average Score per part`)
ggplot(corcombined, aes(x = GroupB, fill ="red"))+geom_histogram(binwidth = 0.2) + xlab("Group A") + ylab("Scores")
#distribution does not look very normal
#dotchart(GroupA$`Average Score per part`)
#dotchart(GroupB$`Average Score per part`)
qplot(seq_along(cronbach_alpha$raw_alpha), cronbach_alpha$raw_alpha, xlab = "Questions 1 to 25", ylab = "Cronbach Alpha score", main = "Cronbach Alpha Score Per Question")
plot(GroupA$`Average Score per part`, GroupB$`Average Score per part`)
#time to check for correlation
#using Wilcoxon signed rank test because of asymmetrical distribution
corcombined <- bind_cols(GroupA$`Average Score per part`,GroupB$`Average Score per part`)
colnames(corcombined)
colnames(corcombined) <- c("GroupA","GroupB")
view(corcombined)
#combining the data so i can plot it.
df_long <- corcombined %>% gather(Group, Value, GroupA:GroupB)
ggplot(df_long, aes(x = Group, y = Value))+ geom_boxplot(fill  = c("lightblue","orange")) + ylab("Scores")+ ggtitle("Boxplots of Group A and Group B") 
wilcox.test(corcombined$GroupA, corcombined$GroupB, paired = TRUE, conf.int = T)
#p value of 0.839
#therefore no correlation between the two groups
